import customtkinter as ctg
from tkinter import messagebox, ttk
from database.conexao import SessionLocal
from core.servicos import PacienteServico, TriagemServico
from ai.modelo_triagem import predizer_prioridade

class JanelaDashboard(ctg.CTk):
    def __init__(self, username, funcao):
        super().__init__()
        self.username = username
        self.funcao = funcao

        self.title("Painel Hospitalar Inteligente")
        self.geometry("1100x700")
        self.geometry("1100x680")
        self.configure(fg_color="#0F172A") # Fundo Geral Escuro
        
        # --- MENU LATERAL ESTILIZADO ---
        self.menu_lateral = ctg.CTkFrame(self, width=240, corner_radius=0, fg_color="#1E293B", border_width=1, border_color="#334155")
        self.menu_lateral.pack(side="left", fill="y")
        self.menu_lateral.pack_propagate(False)

        # --- ÁREA DE CONTEÚDO (CARD CENTRAL) ---
        self.area_conteudo = ctg.CTkFrame(self, corner_radius=20, fg_color="#1E293B", border_width=1, border_color="#334155")
        self.area_conteudo.pack(side="right", fill="both", expand=True, padx=25, pady=25)

        # -- ELEMENTOS DO MENU LATERAL --
        self.lbl_logo_icon = ctg.CTkLabel(self.menu_lateral, text=" MED-AI", font=("Segoe UI", 22, "bold"), text_color="#38BDF8")
        self.lbl_logo_icon.pack(pady=(35, 5), padx=20)
        
        self.lbl_linha = ctg.CTkFrame(self.menu_lateral, height=2, fg_color="#334155", width=180)
        self.lbl_linha.pack(pady=10)

        self.lbl_user = ctg.CTkLabel(self.menu_lateral, text=f"Sessão: {self.username}\nEstatuto: {self.funcao}", font=("Segoe UI", 12), text_color="#94A3B8", justify="center")
        self.lbl_user.pack(pady=(5, 30))

        # Estilo padrão dos botões do menu
        estilo_btn = {
            "height": 42,
            "corner_radius": 10,
            "font": ("Segoe UI", 13, "bold"),
            "fg_color": "transparent",
            "text_color": "#E2E8F0",
            "hover_color": "#334155",
            "anchor": "w"
        }

        self.btn_pacientes = ctg.CTkButton(self.menu_lateral, text="  Registar Paciente", command=self.mostrar_registo_pacientes, **estilo_btn)
        self.btn_pacientes.pack(pady=8, padx=15, fill="x")

        self.btn_triagem = ctg.CTkButton(self.menu_lateral, text="  Nova Triagem (IA)", command=self.mostrar_triagem_ia, **estilo_btn)
        self.btn_triagem.pack(pady=8, padx=15, fill="x")

        self.btn_fila = ctg.CTkButton(self.menu_lateral, text="  Fila de Atendimento", command=self.mostrar_fila_espera, **estilo_btn)
        self.btn_fila.pack(pady=8, padx=15, fill="x")

        self.btn_sair = ctg.CTkButton(self.menu_lateral, text="  Terminar Sessão", fg_color="#341A1A", hover_color="#581C1C", text_color="#F87171", command=self.quit, height=40, corner_radius=10, font=("Segoe UI", 12, "bold"))
        self.btn_sair.pack(side="bottom", pady=30, padx=15, fill="x")

        # Configuração do Estilo da Tabela Treeview (Modo Escuro)
        self.estilizar_tabela_treeview()
        self.mostrar_boas_vindas()

    def estilizar_tabela_treeview(self):
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview",
                        background="#1E293B",
                        foreground="#F8FAFC",
                        fieldbackground="#1E293B",
                        rowheight=35,
                        borderwidth=0,
                        font=("Segoe UI", 11))
        style.configure("Treeview.Heading",
                        background="#0F172A",
                        foreground="#38BDF8",
                        font=("Segoe UI", 11, "bold"),
                        borderwidth=0)
        style.map("Treeview", background=[('selected', '#0284C7')])

    def limpar_area_conteudo(self):
        for widget in self.area_conteudo.winfo_children():
            widget.destroy()

    def mostrar_boas_vindas(self):
        self.limpar_area_conteudo()
        lbl_welcome = ctg.CTkLabel(self.area_conteudo, text="Painel de Controlo Inteligente", font=("Segoe UI", 24, "bold"), text_color="#F8FAFC")
        lbl_welcome.pack(pady=(120, 10))
        lbl_info = ctg.CTkLabel(self.area_conteudo, text="Selecione uma opção no menu lateral para iniciar as operações clínicas.", font=("Segoe UI", 14), text_color="#94A3B8")
        lbl_info.pack(pady=10)

    # ==========================================
    # FORMULÁRIO 1: REGISTO DE PACIENTES
    # ==========================================
    def mostrar_registo_pacientes(self):
        self.limpar_area_conteudo()
        
        ctg.CTkLabel(self.area_conteudo, text="Registar Novo Paciente", font=("Segoe UI", 22, "bold"), text_color="#38BDF8").pack(pady=25)

        config_input = {"width": 420, "height": 40, "corner_radius": 8, "fg_color": "#0F172A", "text_color": "#F8FAFC", "border_color": "#475569"}

        self.txt_nome = ctg.CTkEntry(self.area_conteudo, placeholder_text="Nome Completo do Paciente", **config_input)
        self.txt_nome.pack(pady=10)

        self.txt_nasc = ctg.CTkEntry(self.area_conteudo, placeholder_text="Data de Nascimento (DD/MM/AAAA)", **config_input)
        self.txt_nasc.pack(pady=10)

        self.cb_genero = ctg.CTkComboBox(self.area_conteudo, values=["Masculino", "Feminino", "Outro"], width=420, height=40, corner_radius=8, fg_color="#0F172A", border_color="#475569")
        self.cb_genero.pack(pady=10)

        self.txt_tel = ctg.CTkEntry(self.area_conteudo, placeholder_text="Contacto Telefónico", **config_input)
        self.txt_tel.pack(pady=10)

        ctg.CTkButton(self.area_conteudo, text="Gravar Ficha Mecânica", command=self.salvar_paciente, width=220, height=42, corner_radius=8, font=("Segoe UI", 14, "bold"), fg_color="#0284C7", hover_color="#0369A1").pack(pady=30)

    def salvar_paciente(self):
        db = SessionLocal()
        servico = PacienteServico(db)
        try:
            servico.registar_paciente(
                nome=self.txt_nome.get(),
                data_nascimento=self.txt_nasc.get(),
                genero=self.cb_genero.get(),
                telefone=self.txt_tel.get()
            )
            messagebox.showinfo("Sucesso", "Paciente registado com sucesso!")
            self.mostrar_registo_pacientes()
        except Exception as e:
            messagebox.showerror("Erro", str(e))
        finally:
            db.close()

    # ==========================================
    # FORMULÁRIO 2: TRIAGEM INTELIGENTE (IA)
    # ==========================================
    def mostrar_triagem_ia(self):
        self.limpar_area_conteudo()
        
        ctg.CTkLabel(self.area_conteudo, text="Triagem Assistida por Computador (IA)", font=("Segoe UI", 22, "bold"), text_color="#38BDF8").pack(pady=20)

        db = SessionLocal()
        servico_p = PacienteServico(db)
        lista_pacientes = servico_p.listar_para_combobox()
        db.close()

        if not lista_pacientes:
            ctg.CTkLabel(self.area_conteudo, text=" Registe pelo menos um paciente antes de efetuar a triagem.", text_color="#F59E0B", font=("Segoe UI", 14)).pack(pady=30)
            return

        config_input = {"width": 420, "height": 38, "corner_radius": 8, "fg_color": "#0F172A", "text_color": "#F8FAFC", "border_color": "#475569"}

        self.cb_escolha_paciente = ctg.CTkComboBox(self.area_conteudo, values=lista_pacientes, width=420, height=38, corner_radius=8, fg_color="#0F172A", border_color="#475569")
        self.cb_escolha_paciente.pack(pady=8)

        self.txt_temp = ctg.CTkEntry(self.area_conteudo, placeholder_text="Temperatura corporal (°C) - ex: 37.2", **config_input)
        self.txt_temp.pack(pady=8)

        self.txt_pressao = ctg.CTkEntry(self.area_conteudo, placeholder_text="Pressão Arterial - ex: 12/8", **config_input)
        self.txt_pressao.pack(pady=8)

        self.txt_fc = ctg.CTkEntry(self.area_conteudo, placeholder_text="Frequência Cardíaca (BPM)", **config_input)
        self.txt_fc.pack(pady=8)

        self.txt_dor = ctg.CTkEntry(self.area_conteudo, placeholder_text="Escala de Dor (1 a 10)", **config_input)
        self.txt_dor.pack(pady=8)

        self.txt_sintomas = ctg.CTkEntry(self.area_conteudo, placeholder_text="Notas clínicas / Sintomas visíveis", **config_input)
        self.txt_sintomas.pack(pady=8)

        ctg.CTkButton(self.area_conteudo, text="Submeter ao Algoritmo IA", fg_color="#10B981", hover_color="#059669", command=self.processar_triagem_ia, width=250, height=42, corner_radius=8, font=("Segoe UI", 14, "bold")).pack(pady=25)

    def processar_triagem_ia(self):
        try:
            dados_combo = self.cb_escolha_paciente.get()
            paciente_id = int(dados_combo.split(":")[0])

            temp = float(self.txt_temp.get())
            pressao = self.txt_pressao.get()
            fc = int(self.txt_fc.get())
            dor = int(self.txt_dor.get())
            sintomas = self.txt_sintomas.get()

            prioridade_calculada = predizer_prioridade(temperatura=temp, frequencia=fc, dor=dor)

            db = SessionLocal()
            servico_t = TriagemServico(db)
            servico_t.registar_triagem(paciente_id, temp, pressao, fc, sintomas, prioridade_calculada)
            db.close()

            messagebox.showinfo("Avaliação IA", f"Análise de Risco Concluída!\n\nDiagnóstico: {prioridade_calculada.upper()}")
            self.mostrar_triagem_ia()
        except Exception as e:
            messagebox.showerror("Erro de Inserção", f"Verifique as métricas numéricas digitadas.\nDetalhes: {str(e)}")

    # ==========================================
    # INTERFACE 3: FILA DE ESPERA ORDENADA
    # ==========================================
    def mostrar_fila_espera(self):
        self.limpar_area_conteudo()
        ctg.CTkLabel(self.area_conteudo, text="Fila de Espera Dinâmica e Otimizada", font=("Segoe UI", 22, "bold"), text_color="#38BDF8").pack(pady=20)

        colunas = ("id", "nome", "prioridade", "sintomas", "data")
        tabela = ttk.Treeview(self.area_conteudo, columns=colunas, show="headings", height=15)
        
        tabela.heading("id", text="ID")
        tabela.heading("nome", text="Paciente")
        tabela.heading("prioridade", text="Grau de Risco")
        tabela.heading("sintomas", text="Sintomatologia")
        tabela.heading("data", text="Data/Hora")

        tabela.column("id", width=60, anchor="center")
        tabela.column("nome", width=180)
        tabela.column("prioridade", width=140, anchor="center")
        tabela.column("sintomas", width=280)
        tabela.column("data", width=140, anchor="center")

        # Cores Vibrantes Néon para destacar no Fundo Escuro do Treeview
        tabela.tag_configure("Vermelho", foreground="#F87171", font=("Segoe UI", 11, "bold"))
        tabela.tag_configure("Amarelo", foreground="#FBBF24", font=("Segoe UI", 11, "bold"))
        tabela.tag_configure("Verde", foreground="#34D399", font=("Segoe UI", 11, "bold"))

        db = SessionLocal()
        servico = TriagemServico(db)
        fila = servico.obter_fila_espera()

        for registo in fila:
            tag_prioridade = registo.prioridade_ia 
            tabela.insert("", "end", values=(
                registo.id,
                registo.paciente.nome,
                f" {registo.prioridade_ia.upper()}" if tag_prioridade == "Vermelho" else f" {registo.prioridade_ia.upper()}" if tag_prioridade == "Amarelo" else f" {registo.prioridade_ia.upper()}",
                registo.sintomas,
                registo.data_triagem.strftime("%d/%m %H:%M")
            ), tags=(tag_prioridade,))
            
        db.close()
        tabela.pack(fill="both", expand=True, padx=20, pady=15)