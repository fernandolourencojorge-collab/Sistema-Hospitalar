"""
Módulo de Inteligência Artificial - Classificação de Triagem Hospitalar.
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import pickle
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "ai", "modelo_triagem.pkl")

def gerar_dados_ficticios_treino():
    np.random.seed(42)
    n_amostras = 1000
    temperaturas = np.random.uniform(35.5, 41.0, n_amostras)
    frequencias = np.random.randint(50, 140, n_amostras)
    dor = np.random.randint(1, 11, n_amostras)

    target = []
    for t, f, d in zip(temperaturas, frequencias, dor):
        if t >= 39.5 or f >= 120 or d >= 9:
            target.append(2)  # Vermelho
        elif t >= 38.0 or f >= 100 or d >= 6:
            target.append(1)  # Amarelo
        else:
            target.append(0)  # Verde
    return pd.DataFrame({
        'temperatura': temperaturas, 
        'frequencia_cardiaca': frequencias, 
        'intensidade_dor': dor, 
        'prioridade': target
    })

def treinar_modelo_ia():
    print("A gerar dados clínicos para treino da IA...")
    dados = gerar_dados_ficticios_treino()
    X = dados[['temperatura', 'frequencia_cardiaca', 'intensidade_dor']]
    y = dados['prioridade']

    X_treino, X_teste, y_treino, y_teste = train_test_split(X, y, test_size=0.2, random_state=42)
    print("A treinar o modelo Random Forest Classifier...")
    modelo = RandomForestClassifier(n_estimators=100, random_state=42)
    modelo.fit(X_treino, y_treino)

    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(modelo, f)
    print("Cérebro da IA guardado em 'ai/modelo_triagem.pkl' com sucesso!")


def predizer_prioridade(temperatura, frequencia, dor):
    """Recebe os dados da GUI e usa o arquivo .pkl para adivinhar a prioridade."""
    if not os.path.exists(MODEL_PATH):
        # Se o arquivo não existir, treina automaticamente primeiro
        treinar_modelo_ia()

    with open(MODEL_PATH, 'rb') as f:
        modelo = pickle.load(f)

    # Prepara os dados no formato que o sklearn entende
    dados_paciente = np.array([[temperatura, frequencia, dor]])
    predicao = modelo.predict(dados_paciente)[0]

    # Mapeia o resultado numérico de volta para a cor
    cores = {2: "Vermelho", 1: "Amarelo", 0: "Verde"}
    return cores.get(predicao, "Verde")

if __name__ == "__main__":
    treinar_modelo_ia()