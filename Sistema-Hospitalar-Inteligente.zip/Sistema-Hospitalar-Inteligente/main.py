"""
Sistema Hospitalar Inteligente - Ponto de Entrada Principal (Main).
Autor: ferna
Data: 31/05/2026
"""
from database.conexao import engine, Base, SessionLocal
from database.modelos import UtilizadorModelo, PacienteModelo, TriagemModelo
from core.servicos import UtilizadorServico
from gui.login import TelaLogin
import sys

def inicializar_sistema():
    print("====================================================")
    print("A inicializar a Base de Dados do Hospital...")
    # Cria todas as tabelas no SQLite se elas ainda não existirem
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    servico = UtilizadorServico(db)
    try:
        # Garante que existe sempre o utilizador padrão 
        servico.criar_utilizador_inicial(
            username="admin", 
            password_plana="admin123", 
            funcao="Médico"
        )
        print("✔ Utilizador de teste 'admin' verificado/criado com sucesso!")
    except Exception as e:
        print(f"⚠ Nota ao verificar utilizador inicial: {e}")
    finally:
        db.close()
        
    print(" Sistema de Base de Dados operacional e pronto!")
    print("====================================================")

if __name__ == "__main__":
    # 1. Corre as configurações iniciais de tabelas e dados
    inicializar_sistema()
    
    # 2. Arranca a Interface Gráfica (GUI) com CustomTkinter
    print("A abrir o ecrã de Autenticação...")
    app = TelaLogin()
    app.mainloop()
    print("\nSistema encerrado corretamente. Até à próxima!")